<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Category;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
// use App\Helpers\Common_helper::class;
use Session;
use DB;

class UserController extends Controller
{
    
public function index(){
  $pageTitle = "Dashboard";
    $user_id = session::get('roleId');
	 $user = User::with(['category_detail'])
       ->where('id', '=', $user_id)
       ->first();
  	return view("dashboard",compact('user'));
  }

  public function profile(){
  	$pageTitle = "Profile";
    $user_id = session::get('roleId');
	 $user = User::with(['category_detail'])
       ->where('id', '=', $user_id)
       ->first();
  	return view("user_profile",compact('user','pageTitle'));
  }

}
