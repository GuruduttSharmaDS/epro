<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Category;
use App\Models\UserProfileView;
use App\Models\UserReview;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Helpers\Common_helper;
// use App\Helpers\Common_helper::class;
use Session;
use DB;


class HomeController extends Controller
{
  public function index(){

   // $users = DB::select('select user.id, user.*, (SELECT skill from fp_skills where fp_skills.id  = (SELECT skill_id from fp_user_skills where fp_user_skills.user_id  = user.id limit 0,1)  limit 0,1) as skill from fp_users as user where user.status =0');
       
      $gaurd_count = User::where(['status' => 0])->get()->count();
      $client_count = User::where(['status' => 0])->get()->count();

       $users = User::with(['category_detail'])
       ->where('status', '=', '0')
       ->get();
        return view("welcome",compact('users','client_count','gaurd_count'));
  }
  public function searchResult(){

    $category_list = Category::all()
         ->where('status', '=', '0')   
         ->pluck('category_name', 'id');

        $weapon_list  = DB::table("fp_weapons")
         ->where('status', '=', '0')   
         ->pluck('weapon_name', 'id');

         $users = User::with(['category_detail'])
             ->where('status', '=', '0');
            
         if(isset($_POST) && !empty($_POST)){
             print_r($_POST);exit;
         }  
        if(isset($_GET) && !empty($_GET)){
          print_r($_GET);exit;
          if(!isset($_GET['search'])){
              $_GET['search'] = $_GET;
          }
          if(isset($_GET['search']['country']) && !empty($_GET['search']['country'])){
             
              $users = $users->where('name', 'LIKE', '%' . $_GET['search']['country'] . '%');
          }
          if(isset($_GET['search']['keyword']) && !empty($_GET['search']['keyword'])){

             
              $users = $users->where('first_name', 'LIKE', '%' . $_GET['search']['keyword'] . '%');
              $users = $users->orWhere('last_name', 'LIKE', '%' . $_GET['search']['keyword'] . '%');
              $users = $users->orWhere('city', 'LIKE', '%' . $_GET['search']['keyword'] . '%');
          }
          
        }

        $users = $users->paginate(5);
        if(isset($_GET['search']) && !empty($_GET['search'])){
            $users->appends(['search' => $_GET['search']]); 
        }
          
    
  	     return view("searchresult",compact('users','category_list', 'weapon_list'));
  }

  public function gaurdDetail($id= null){
     $user_id = session::get('roleId');
      $common_lib = new Common_helper();

         $count_view = DB::table("fp_user_profile_views")
         ->where('created_at', 'like', date('Y-m-d').'%')
         ->where('user_id', '=', $id)
         ->where('client_id', '=', $user_id)
         ->get()->count();
         if($count_view <= 0){
             if($user_id != $id){
                $UserProfileView = new UserProfileView;
                $UserProfileView->client_id = $user_id;
                $UserProfileView->user_id = $id;
                $UserProfileView->save();

             }
         }

       $gaurd = User::with(['category_detail'])
       ->where('id', '=', $id)
       ->first();
        
        $total_count = $common_lib->getTotalRating($id);
     
       $job_done_count =  DB::table("fp_user_hire")
         ->where('valid_upto', 'like', date('Y-m-d').'%')
         ->get()->count();

        $reviews = UserReview::with(['job_detail'])
                  ->where('user_id', '=', $id)
                  ->paginate(5);


    return view("gaurd_detail",compact('gaurd','job_done_count','reviews','total_count'));

  }




  public function logout(Request $request){
  	
  	$request->session()->flush();
    Session::forget(['email','roleId','role','first_name','last_name']); 
    return redirect("/");
  }
  public function dashboard(){
  	return view("dashboard");
  }
  public function forgotpassword(Request $request){
  	/*return $request;
  	exit();*/
  	return view("newpassword");
  }
}