@extends('frontend.layouts.user_dashboard_layout')

@section('title', 'FreelanceEP')
@section('body')

<div class="banner_search">
				<h1><?php echo $pageTitle; ?></h1>				
			</div>	
			<div class="search_main">
				<div class="container">
					<div class="row">
						 @include("frontend.layouts.user_dashboard_sidebar")
						<div class="col-12 col-md-8 col-lg-8 col-sm-7">
							<div class="hire_companies">
								<label>Name : {{ $user->first_name.' '.$user->last_name }}</label>
								<label>Email : {{ $user->email}}</label>
								<label>Category : @if(!empty($user->category_detail)){{ $user->category_detail->category_name }}@endif</label>
								<label>Price : ${{ $user->price}}/hr</label>
								<label>Pincode : ${{ $user->pincode}}/hr</label>
								<label>Price : ${{ $user->price}}/hr</label>
								<label>About me : ${{ $user->about}}/hr</label>

							</div>
						</div>
					</div>
				</div>
			</div>

@endsection
