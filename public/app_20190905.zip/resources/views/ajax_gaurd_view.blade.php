<div class="total_search">
								<!--<div class="total_count">01-48 of 57143 results for "<b>Private Security</b>"
								</div>-->
								<?php 
									if(isset($_POST) && !empty($_POST)){
								?>
								<div class="total_filter">
									<ul>
										<?php
										if(isset($_POST['category']) && !empty($_POST['category'])){
											foreach($_POST['category'] as $category){
												$category = user_category_data($category);
												echo "<li>".$category->category_name."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['price']) && !empty($_POST['price'])){
											foreach($_POST['price'] as $price){
												echo "<li>".$price."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['gender']) && !empty($_POST['gender'])){
											foreach($_POST['gender'] as $gender){
												echo "<li>".$gender."</li>";
											}
										}
										?>
										<?php
										if(  isset($_POST['duration']) && !empty($_POST['duration'])){
											foreach($_POST['duration'] as $duration){
												echo "<li>".$duration."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['weapon']) &&  !empty($_POST['weapon'])){
											foreach($_POST['weapon'] as $weapon){
												echo "<li>".$weapon."</li>";
											}
										}
										?>
																			
									</ul>
									<a href="{{route('search-result')}}"><i class="fas fa-times-circle"></i> Clear all Filters</a>
								</div>

								<?php

									}
								?>
								
							</div>
							
							 <?php
							if(!empty($users)){

                                           if(!empty($user->image)){
                                             $img = $user->image;
                                         }else{
                                        $img = 'no-img.png';

                                         }
                                           
                                            
                            ?>
                            @foreach($users as $user)
                        
							<div class="freelancer_list">

								<div class="profile">
									<div class="img_fP">
										<img src="{{asset('/uploads/'.$img)}}" alt="">
									</div>
									<div class="name_loct">

										<h3><a class="checkuserLogin" href="{{asset('/gaurd-detail/'.$user->id)}}"
											>
											{{ $user->first_name.' '.$user->last_name }}
										</a> 
										@if($user->is_user_verified == '1')
										<span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										@endif 
											
										<h4>@if(!empty($user->category_detail)){{ $user->category_detail->category_name }}@endif</h4>
										<div class="location">
												<h4>
													<span><img src="{!! asset('assets/frontend/img/loct.png') !!}" alt="Location"> Location</span>
													<b>{{ $user->country }}</b>
												</h4>
												<h4>
													<span><img src="{!! asset('assets/frontend/img/rate_img.png') !!}" alt="Rate"> Rate</span>
													<b>${{ $user->price}}/hr</b>
												</h4>
												<h4>
													<span><img src="{!! asset('assets/frontend/img/success.png') !!}" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>{{$user->about}}</p>
									<?php

								    $skills = user_skill_data($user->id);
								    if(!empty($skills)){
								    	?>
								    	<div class="soft_skills">
										<ul>
									    @foreach ($skills as $skill)
									    <li>{{$skill->skill_data->skill}}</li>
									    @endforeach
									    </ul>
										</div>	
								    <?php	
									}
									 ?>
								</div>
							</div>
							 @endforeach
							 <div class="paginating">

									<ul class="pagination searchpagination">
									{{ $users->links() }}	
								
								</ul>
								</div>

							<?php 
							}else{

								echo "no record found";

							}
							?>

							
							