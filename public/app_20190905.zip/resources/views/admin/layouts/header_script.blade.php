
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="{!! asset('assets/images/icon/favicon.ico') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/bootstrap.min.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/font-awesome.min.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/themify-icons.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/metisMenu.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/owl.carousel.min.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/slicknav.min.css') !!}">
    <link rel="stylesheet" href="{!! asset('assets/css/custom.css') !!}">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <script type="text/javascript">
        var BASEURL = "{{route('home')}}";
    </script>