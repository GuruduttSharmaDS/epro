<div class="col-12 col-md-4 col-lg-4 col-sm-5">
							<div class="d_board_prof">
							<div class="profile">
								<div class="profile_img">
									<?php
									if(!empty($user->image)){
                                             $img = $user->image;
                                         }else{
                                          $img = 'no-img.png';

                                         }
                                         ?>
									<span><img src="<?php echo e(asset('/uploads/'.$img)); ?>" 
										alt="profile img"></span>
								</div>
								<div class="name_desg">
									<h2><?php echo e($user->first_name.' '.$user->last_name); ?></h2>
									<h3><?php if(!empty($user->category_detail)): ?><?php echo e($user->category_detail->category_name); ?><?php endif; ?></h3>
									<a href="#">View Profile</a>
								</div>
							</div>
							<div class="other_links">
								<ul class="user-dashboard">
									<li class=""><a href="<?php echo e(route('user-dashboard')); ?>"><i class="flaticon-dashboard"></i>Dashboard</a></li>
									<li class=""><a href="<?php echo e(route('user-profile')); ?>"><i class="flaticon-man-user"></i>profile</a></li>
									<!--<li class=""><a href=""><i class="flaticon-bookmark-star"></i>Bookmarks</a></li>-->
									<li class=""><a href="<?php echo e(route('user-change-password')); ?>"><i class="flaticon-lock"></i>Change Password</a></li>
									<li class=""><a href=""><i class="flaticon-time"></i>History</a></li>
									<li class=""><a href="<?php echo e(route('user-task')); ?>"><i class="flaticon-task-complete"></i>tasks</a></li>
									<li><a href="<?php echo e(route('logoutfront')); ?>"><i class="flaticon-logout"></i>logout</a></li>
								</ul>
							</div>
						</div>
					</div><?php /**PATH C:\wamp64\www\epro\resources\views/frontend/layouts/user_dashboard_sidebar.blade.php ENDPATH**/ ?>