</div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright <?=date('Y')?>. All right reserved. <a href="javascript:">Market Place</a>.</p>
            </div>
        </footer>
        <div class="hide"> <?php echo csrf_field(); ?></div>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- jquery latest version -->
    <script src="<?php echo asset('assets/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
    <!-- bootstrap 4 js -->
    <script src="<?php echo asset('assets/js/popper.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/owl.carousel.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/metisMenu.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/jquery.slimscroll.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/jquery.slicknav.min.js'); ?>"></script>
<?php /**PATH C:\wamp64\www\epro\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>