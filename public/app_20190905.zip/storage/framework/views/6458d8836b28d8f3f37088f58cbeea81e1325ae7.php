<?php $__env->startSection('title', 'FreelanceEP'); ?>
<?php $__env->startSection('body'); ?>
<div class="login_form">
                <div class="alert alert-danger print-error-msg" style="display:none">
                    <ul></ul>
                </div>
                <form action="#" class="needs-validation loginauth" onsubmit="forgot_password_email(this,event)" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="form-group msg">
                    </div>
                    <div class="form-group">
                        <label for="uname">Email:</label>
                        <input type="text" class="form-control" id="forgotemail" placeholder="Enter email address" name="email" required>
                        <!-- <div class="valid-feedback">Valid.</div> -->
                        <!-- <div class="invalid-feedback">Please fill out this field.</div> -->
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password"  name="pswd" required>
                        
                    </div>
                    <div class="form-group">
                        <label for="cpwd">Confirm Password:</label>
                        <input type="password" class="form-control" id="confirmPassword" name="cpswd" required>
                        
                    </div>
                    <input type="hidden" name="action" value="password_mail">
                    <button type="button" class="btn btn-primary mu-send-btn validate-password-email registerform btn-regis" value="Login">Login</button>
                    
                </form>
            </div>
<?php $__env->stopSection(); ?>            
<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelancep\resources\views/newpassword.blade.php ENDPATH**/ ?>