<!doctype html>
<html class="no-js" lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Market Place - <?php echo $__env->yieldContent('title'); ?></title>
 
        
        <?php echo $__env->make("admin.layouts.header_script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php $__env->startSection("header-page-script"); ?>
        <?php echo $__env->yieldSection(); ?>
    </head>
    <body>
        <!--[if lt IE 8]>
                <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
            <![endif]-->
        <!-- preloader area start -->
        <div id="preloader">
            <div class="loader"></div>
        </div>
        <!-- preloader area end -->
        <!-- page container area start -->
        <div class="page-container">

            
            <?php echo $__env->make("admin.layouts.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php echo $__env->make("admin.layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
            

            
            <?php $__env->startSection("content"); ?>
            <?php echo $__env->yieldSection(); ?>
            
            
            <?php echo $__env->make("admin.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            
            <?php $__env->startSection("footer-page-script"); ?>
            <?php echo $__env->yieldSection(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\freelancep\resources\views/admin/layouts/layout.blade.php ENDPATH**/ ?>