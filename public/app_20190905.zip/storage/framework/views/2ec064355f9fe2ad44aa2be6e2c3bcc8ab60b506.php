<?php $__env->startSection('title', 'FreelanceEP'); ?>
<?php $__env->startSection('body'); ?>
 <div class="banner_search">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="user_info">
                                <div class="user_img">
                                     <?php
                                        if(!empty($gaurd->image)){
                                            $img = $gaurd->image;
                                        }else{
                                            $img = 'no-img.png';

                                        }
                                      ?>
                                    <img src="<?php echo e(asset('/uploads/'.$img)); ?>" alt="user image" class="img-fluid">
                                </div>
                                <div class="profile_details">
                                    <h2><?php echo e($gaurd->first_name.' '.$gaurd->last_name); ?></h2>
                                    <?php if(!empty($gaurd->category_detail)): ?><h4><?php echo e($gaurd->category_detail->category_name); ?></h4><?php endif; ?>
                                    <h4><b><?php echo e($total_count->average_rating); ?></b> gaurd(<?php echo e($total_count->totalreview); ?> Feedbacks)</h4>
                                    <h3><span><i class="fas fa-map-marker-alt"></i></span> <?php echo e($gaurd->country); ?> <?php if($gaurd->is_user_verified == '0'): ?>
                                        <strong> Verified</strong>
                                        <?php endif; ?> </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>              
            </div>
            <div class="profile_main">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="about_me">
                                <h2>About Me</h2>                               
                                <p><?php if(!empty($gaurd->about)){
                                    echo $gaurd->about;
                                }else{
                                    echo "No data found";

                                }

                                ?>

                                </p>
                            </div>
                            <div class="work_history">
                                <h2><i class="far fa-thumbs-up"></i> Work History and Feedback</h2>

                                <?php 
                                if(!empty($reviews)){
                                    foreach($reviews as $review){
                                ?>

                                     <div class="work_post">
                                    <h3><?php 
                                    if(isset($review->job_detail->category_id)){
                                         $cat_data = user_category_data($review->job_detail->category_id);
                                        echo  $cat_data->category_name;    
                                    }
                                   
                                    ?></h3>
                                    <!--<h5>Rated as Freelancer</h5>-->
                                    <div class="rating">
                                        <h3><?php echo e($review->rating); ?></h3>
                                        <ul>
                                           
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                        </ul>
                                        <div class="calend"><i class="far fa-calendar-alt"></i> <?php echo e($review->created_at); ?></div>
                                    </div>
                                    <p><?php echo e($review->review); ?></p>
                                </div>


                                    <?php   
                                    }?>
                                     <ul class="pagination">
                                        <?php echo e($reviews->links()); ?>

                                </ul>
                                <?php
                                }else{
                                    echo "No Feedback found";
                                }
                                ?>
                        </div>
                    </div>
                        <div class="col-md-4">
                            <div class="statistics">
                                <h3><strong>$<?php echo e($gaurd->price); ?></strong><br>Hourly Rate</h3>
                                <h3><strong><?php echo e($job_done_count); ?></strong><br>Jobs Done</h3>
                                <h3><strong>22</strong><br>Rehired</h3>
                            </div>
                            <h5 class="name_desg"><a href="#">Make a Offer</a></h5>
                            <div class="achieve">
                                <h3>Skills</h3>
                                <ul>
                                    <?php

                                    $skills = user_skill_data($gaurd->id);
                                    if(!empty($skills->skill_data)){
                                        ?>
                                        <div class="soft_skills">
                                        <ul>
                                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($skill->skill_data->skill); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </div>  
                                    <?php   
                                    }else{
                                        echo "No data found";
                                    }
                                     ?>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\epro\resources\views/gaurd_detail.blade.php ENDPATH**/ ?>