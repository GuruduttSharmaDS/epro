
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><img src="<?php echo asset('assets/frontend/img/logo.png'); ?>" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="<?php echo e(route('dashboard')); ?>"><i class="ti-dashboard"></i> <span>Dashboard</span></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('skills')); ?>"><i class="ti-palette"></i> <span>Manage Skills</span></a>
                            </li>
                             <li>
                                <a href="<?php echo e(route('category')); ?>"><i class="ti-palette"></i> <span>Manage Categories</span></a>
                            </li>
                             <li>
                                <a href="<?php echo e(route('weapons')); ?>"><i class="ti-palette"></i> <span>Manage Weapons</span></a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i><span>Manage Users
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="<?php echo e(route('adduser')); ?>">Add New</a></li>
                                    <li><a href="<?php echo e(route('listuser')); ?>">List</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-briefcase"></i><span>Manage Clients
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="<?php echo e(route('addclient')); ?>">Add New</a></li>
                                    <li><a href="<?php echo e(route('listclient')); ?>">List</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('listquery')); ?>"><i class="ti-email"></i> <span>Manage Contact Query</span></a>
                            </li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->

<?php /**PATH C:\wamp64\www\epro\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>