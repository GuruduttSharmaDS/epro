
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo asset('assets/images/icon/favicon.ico'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/themify-icons.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/metisMenu.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/owl.carousel.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/slicknav.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/custom.css'); ?>">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <script type="text/javascript">
        var BASEURL = "<?php echo e(route('home')); ?>";
    </script><?php /**PATH C:\xampp\htdocs\freelancep\resources\views/admin/layouts/header_script.blade.php ENDPATH**/ ?>