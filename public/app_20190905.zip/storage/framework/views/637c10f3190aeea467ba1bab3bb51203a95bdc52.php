<?php $__env->startSection('title', 'FreelanceEP'); ?>
<?php $__env->startSection('body'); ?>

<div class="banner_search">
				<h1>Search Result</h1>
				<ul class="breadcrumb">
					<li class="breadcrumb-item"><a href="#">Home</a></li>
					<li class="breadcrumb-item active">Freelancers</li>
					
				</ul>
			</div>	
			<div class="search_main">
				<div class="container">
					<div class="row">
						<div class="col-12 col-md-4 col-lg-4 col-sm-5">

							<div class="filters">
								<h2>Categories</h2>
								<form class="form-inline">
									<input class="form-control" type="search" placeholder="Search Categories" aria-label="Search">
									<a class="submit_btn"><img src="<?php echo asset('assets/frontend/img/search.png'); ?>" width="18px"></a>
								</form>
								<ul>
									<li>
										<div class="filt_name">
											<input type="checkbox" id="pri_sec" name="fruit-1" value="Private Security">
											<label for="pri_sec">Private Security</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="tra_sec" name="tra_sec" value="Transport Security">
											<label for="tra_sec">Transport Security</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="home_sec" name="home_sec" value="Home Security">
											<label for="home_sec">Home Security</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="hosp_sec" name="hosp_sec" value="Hospital Security">
											<label for="hosp_sec">Hospital Security</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="hotel_sec" name="hotel_sec" value="Hotel Security">
											<label for="hotel_sec">Hotel Security</label>
										</div>
									</li>
								</ul>
							</div>	<!-- filters -->
							<div class="filters">
								<h2>Hourly Rate</h2>								
								<ul>
									<li>
										<div class="filt_name">
											<input type="checkbox" id="ten_below" name="ten_below" value="$10 and Below">
											<label for="ten_below">$10 and Below</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="10_30" name="10_30" value="$10-$30">
											<label for="10_30">$10-$30</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="30_60" name="30_60" value="$30-$60">
											<label for="30_60">$30-$60</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="60_90" name="60_90" value="$60-$90">
											<label for="60_90">$60-$90</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="90_above" name="90_above" value="$90 & Above">
											<label for="90_above">$90 & Above</label>
										</div>
									</li>
								</ul>
							</div>	<!-- filters -->					
							<div class="filters">
								<h2>Gender</h2>								
								<ul>
									<li>
										<div class="filt_name">
											<input type="checkbox" id="male" name="male" value="Male">
											<label for="male">Male</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="female" name="female" value="Female">
											<label for="female">Female</label>
										</div>
									</li>
								</ul>
							</div>	<!-- filters -->
							<div class="filters">
								<h2>Armor</h2>								
								<ul>
									<li>
										<div class="filt_name">
											<input type="checkbox" id="Pistol" name="Pistol" value="Pistol">
											<label for="Pistol">Pistol</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="Revolver" name="Revolver" value="Revolver">
											<label for="Revolver">Revolver</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="rifel" name="rifel" value="Rifel">
											<label for="rifel">Rifel</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="bp_jacket" name="bp_jacket" value="Bulletproof Jacket">
											<label for="bp_jacket">Bulletproof Jacket</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="body_armor" name="body_armor" value="Body Armor">
											<label for="body_armor">Body Armor</label>
										</div>
									</li>
								</ul>
							</div>	<!-- filters -->	
							<div class="filters">
								<h2>Duration</h2>								
								<ul>
									<li>
										<div class="filt_name">
											<input type="checkbox" id="one_day" name="one_day" value="One Day">
											<label for="one_day">One Day</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="one_week" name="one_week" value="One Week">
											<label for="one_week">One Week</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="one_month" name="one_month" value="One Month">
											<label for="one_month">One Month</label>
										</div>
									</li>
									<li>										
										<div class="filt_name">
											<input type="checkbox" id="one_year" name="one_year" value="One Year">
											<label for="one_year">One Year</label>
										</div>
									</li>									
								</ul>
								<a href="#">Customize Duration...</a>
							</div>	<!-- filters -->											
						</div>
						<div class="col-12 col-md-8 col-lg-8 col-sm-7">
							<div class="total_search">
								<div class="total_count">01-48 of 57143 results for "<b>Private Security</b>"
								</div>
								<div class="total_filter">
									<ul>
										<li>Private Security</li>
										<li>$10-$30</li>
										<li>Male</li>
										<li>Pistol</li>
										<li>One Day</li>										
									</ul>
									<a href="#"><i class="fas fa-times-circle"></i> Clear all Filters</a>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile1.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile2.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?> " alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile3.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile4.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile5.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile6.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
							<div class="freelancer_list">
								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo asset('assets/frontend/img/profile7.jpg'); ?>" alt="">
									</div>
									<div class="name_loct">
										<h3> Alfredo Bossard  <span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<h4>Private Security</h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b>london</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Rate"> Rate</span>
													<b>$60/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliquaenim ad minim veniamac quis nostrud exercitation ullamco laboris...</p>
									<div class="soft_skills">
										<ul>
											<li>Honest</li>
											<li>Responsible</li>
											<li>Good Communication</li>
											<li>Basic knowledge of IT</li>											
										</ul>
									</div>
								</div>
							</div>
								<div class="paginating">
									<ul class="pagination ">
								<li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-left"></i></a></li>
								<li class="page-item"><a class="page-link" href="#">1</a></li>
								<li class="page-item"><a class="page-link" href="#">2</a></li>
								<li class="page-item"><a class="page-link" href="#">3</a></li>
								<li class="page-item"><a class="page-link" href="#">4</a></li>
								<li class="page-item"><a class="page-link" href="#">5</a></li>
								<li class="page-item"><a class="page-link" href="#">6</a></li>
								<li class="page-item"><a class="page-link" href="#">7</a></li>
								<li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-right"></i></a></li>
								</ul>
								</div>
						</div>
					</div>
				</div>
			</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelancep\resources\views/searchresult.blade.php ENDPATH**/ ?>