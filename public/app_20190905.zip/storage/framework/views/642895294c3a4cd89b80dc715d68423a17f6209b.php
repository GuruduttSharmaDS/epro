<html><head></head><body style="margin: 0;"><table style="font-family: Verdana, Geneva, sans-serif; color: #454545; min-width: 334px;" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr>
      <td style="background: rgb(21, 54, 84) none repeat scroll 0% 0%; padding: 5px 2% 0px; border-radius: 3px 0px 0px;" height="60px" valign="middle" width="50%"><a href="[[[SITEURL]]]" target="_blank"><img class="CToWUd" src="[[[LOGO]]]" width="57" border="0"></a></td>
      <td style="padding: 5px 2% 5px; color: rgb(255, 255, 255); border-radius: 0px 3px 0px 0px; text-align: right; background: rgb(21, 54, 84) none repeat scroll 0% 0%;" height="60px" valign="middle" width="50%">
        <p style="font-size: 10px; font-weight: bold;">Connecting the FREELANCEP</p>
      </td>
    </tr>
  </tbody>
</table><!--header table-->

<table style="background: rgb(251, 251, 251) none repeat scroll 0% 0%; color: rgb(69, 69, 69); min-width: 320px;" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr width="100%">
      <td align="center">
        <center>
        <table style="max-width: 500px; font-family: Verdana, Geneva, sans-serif; padding: 20px 0; margin: 0 auto;" border="0" cellpadding="0" cellspacing="0" width="100%">
          <tbody>
            <tr>
              <td colspan="2" style="padding: 5px 15px 20px 15px;" align="left">
                <h2 style="font-size: 15px;color: #153654; text-align: justify;">Reset Your FREELANCEP account apssword!</h2>
                <p style="font-size: 11px;text-align: justify;">Please click on reset password to reset FREELANCEP account password registration</p>
              </td>
            </tr>
            <tr>
              <td style="padding:10px 5px 10px 5px" align="center">
                <div style="width: 220px; min-height: 38px; border-radius: 3px; background: transparent linear-gradient(to bottom, rgb(21, 54, 84) 0%, rgb(25, 70, 111) 100%) repeat scroll 0% 0%">
                    <a href="<?php echo e($url); ?>" style="display:block;width:215px;min-height:38px;text-align:center;font-size:17px;font-weight:bold;color:#fff;text-decoration:none;line-height:38px" target="_blank">Reset Password</a>
                </div>
              </td>
            </tr>
			<tr>
              <td>
                <p style="font-size: 11px; text-align: right;"><em>-FREELANCEP Team</em></p>
              </td>
            </tr>
          </tbody>
        </table><!--body table-->
        </center>
      </td>
    </tr>
    <tr>
      <td>
        <table align="center" width="100%" cellspacing="0" cellpadding="0" border="0">
          <tbody>
            <tr>
              <td style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; line-height: 1.4; font-weight: 300; text-align: center; font-size: 12px; color: #464646" align="center">
                  Reply to this email will not be read. If you need to contact us please see how to do so <a href="[[[SITEURL]]]" target="_blank" style="color: #125b9c;text-decoration: none;"><b>here|</b></a>.
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
    <tr>
      <td height="10"></td>
    </tr>
  </tbody>
</table>

<table style="font-family: Verdana, Geneva, sans-serif; min-width: 334px;" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody>
    <tr style="background: rgb(22, 60, 94) none repeat scroll 0% 0%; color: rgb(255, 255, 255);" height="45px" valign="middle">
      <td style="padding-left: 2%; padding-right: 2%; border-radius: 0 0 3px 3px" align="left" valign="middle">
        <span style="-webkit-text-size-adjust: none; font-size: 10px; float: left;">Copyright &copy; [[[YEAR]]] FREELANCEP. All rights reserved</span>
        <!-- <span style="-webkit-text-size-adjust: none; font-size: 10px; float: right;"><a href="[[[TERMURL]]]" style="color: #eee; text-decoration: none;">Terms of Service</a></span> -->
      </td>
      <td style="border-radius: 0 0 3px 3px;" align="right" valign="middle">
      </td>
    </tr>
  </tbody>
</table><!--footer table--></body></html><?php /**PATH C:\xampp\htdocs\freelancep\resources\views/email_templates/forgot_password.blade.php ENDPATH**/ ?>