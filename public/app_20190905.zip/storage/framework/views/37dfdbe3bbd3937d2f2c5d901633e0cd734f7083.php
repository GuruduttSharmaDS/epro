<?php $__env->startSection('title', 'FreelanceEP'); ?>
<?php $__env->startSection('body'); ?>

<div class="banner_search">
				<h1>Dashboard</h1>				
			</div>	
			<div class="search_main">
				<div class="container">
					<div class="row">
						<div class="col-12 col-md-4 col-lg-4 col-sm-5">
							<div class="d_board_prof">
							<div class="profile">
								<div class="profile_img">
									<span><img src="<?php echo asset('assets/frontend/img/profile1.jpg'); ?>" alt="profile img"></span>
								</div>
								<div class="name_desg">
									<h2>Louanne Mattioli</h2>
									<h3>Personal Guard</h3>
									<a href="#">View Profile</a>
								</div>
							</div>
							<div class="other_links">
								<ul>
									<li><a href=""><i class="flaticon-dashboard"></i>Dashboard</a></li>
									<li><a href=""><i class="flaticon-man-user"></i>profile</a></li>
									<li><a href=""><i class="flaticon-bookmark-star"></i>Bookmarks</a></li>
									<li><a href=""><i class="flaticon-lock"></i>Change Password</a></li>
									<li><a href=""><i class="flaticon-time"></i>History</a></li>
									<li><a href=""><i class="flaticon-task-complete"></i>tasks</a></li>
									<li><a href=""><i class="flaticon-settings-work-tool"></i>settings</a></li>
									<li><a href=""><i class="flaticon-logout"></i>logout</a></li>
								</ul>
							</div>
						</div>
					</div>
						<div class="col-12 col-md-8 col-lg-8 col-sm-7">
							<div class="total_tasks">
								<div class="jobs">
									<h3>complete Jobs</h3>
									<h4>22 <span><img src="<?php echo asset('assets/frontend/img/job.svg'); ?>"></span></h4>
								</div>
								<div class="jobs reviews">
									<h3>Reviews</h3>
									<h4>28 <span><img src="<?php echo asset('assets/frontend/img/reviews.svg'); ?>"></span></h4>
								</div>
								<div class="jobs views">
									<h3>This Month Views</h3>
									<h4>987 <span><img src="<?php echo asset('assets/frontend/img/views.svg'); ?>"></span></h4>
								</div>
							</div>
							<div class="revenue">
								<img src="<?php echo asset('assets/frontend/img/revenue.svg'); ?>" class="img-fluid">
							</div>
							<div class="hire_companies">
								<h2><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"> Hire Companies</h2>

								<ul>
									<li><span><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"></span>
										<h3><b>InterContinental Hotels Group </b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
									</li>
									<li><span><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"></span>
										<h3><b>InterContinental Hotels Group </b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
									</li>
									<li><span><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"></span>
										<h3><b>InterContinental Hotels Group </b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
									</li>
									<li><span><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"></span>
										<h3><b>InterContinental Hotels Group </b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
									</li>
									<li><span><img src="<?php echo asset('assets/frontend/img/hire.svg'); ?>" alt=" Hire Companies"></span>
										<h3><b>InterContinental Hotels Group </b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
									</li>
								</ul>
							</div>
							<div class="hire_companies work_history">
								<h2><img src="<?php echo asset('assets/frontend/img/w_history.svg'); ?>" alt="work history and feedback">work history and feedback</h2>
								<ul>
									<li>
										<div class="posted">
										<h3><b>InterContinental Hotels Group</b>www.ihg.com / Denham,
										 	South East England, England, United Kingdom
										</h3>
										<time class="calen"><img src="<?php echo asset('assets/frontend/img/cal.svg'); ?>" alt="">August 2019</time>
										</div>
										<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
										</div>
										<p>
											Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.
										</p>
									</li>
									<li>
										<div class="posted">
										<h3><b>Ers Security Alarm Systems</b>www.erssecurity.com / El Monte, CA, United States
										</h3>
										<time class="calen"><img src="<?php echo asset('assets/frontend/img/cal.svg'); ?>" alt="">August 2019</time>
										</div>
										<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
										</div>
										<p>
											Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.
										</p>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelancep\resources\views/dashboard.blade.php ENDPATH**/ ?>