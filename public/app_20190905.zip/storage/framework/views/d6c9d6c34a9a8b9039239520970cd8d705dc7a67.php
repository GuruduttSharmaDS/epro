

<?php $__env->startSection("title","Admin Dashboard | Market Place"); ?>

<?php $__env->startSection("header-page-script"); ?>   
    
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="<?php echo asset('assets/css/jquery.dataTables.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('assets/css/dataTables.bootstrap4.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('assets/css/responsive.bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('assets/css/jqueryui.min.css'); ?>">

    <!-- others css -->
    <link rel="stylesheet" href="<?php echo asset('assets/css/typography.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/default-css.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/styles.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/css/responsive.css'); ?>">
    <!-- modernizr css -->
    <script src="<?php echo asset('assets/js/vendor/modernizr-2.8.3.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-12">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                <li><span>Clients</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- Dark table start -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Clients</h4>
                                <div class="data-tables datatable-dark">
                                    <table class="table my-dataTable table-hover table-bordered" id="sampleTable" class="text-center">  
                                        <thead class="text-capitalize">
                                            <tr>
                                                <th>Image</th>
                                                <th>Name</th>
                                                <th>Email Address</th>
                                                <th>Phone</th>
                                                <th>Create Date</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Dark table end -->
                </div>
            </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection("footer-page-script"); ?>
    <!-- Start datatable js -->
    <script src="<?php echo asset('assets/js/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/dataTables.bootstrap4.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/dataTables.responsive.min.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/responsive.bootstrap.min.js'); ?>"></script>
    <!-- others plugins -->
    <script src="<?php echo asset('assets/js/plugins.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/scripts.js'); ?>"></script>
    <script src="<?php echo asset('assets/js/admin.js'); ?>"></script> 
    <script>
        $(function() {
            $('#sampleTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(url('/dashboard/client_data')); ?>',
                columns: [
                { data: 'image', name: 'image' },
                { data: 'first_name', name: 'first_name' },
                { data: 'email', name: 'email' },
                { data: 'phone', name: 'phone' },
                { data: 'created_at', name: 'created_at' },
                { data: 'status', name: 'status' },
                { data: 'action', name: 'action' }
                ]
            });
        });
    </script>

    <script>
        $(function () {

            $(document).on("click", ".btn-delete", function () {

                var conf = confirm("Are you sure want to delete ?");

                if (conf) {

                    // ajax call functions
                    var delete_id = $(this).attr("data-id"); // delete id of delete button

                    var postdata = {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        "hiddenval": delete_id
                    }

                    $.post("<?php echo e(route('deleteclient')); ?>", postdata, function (response) {

                        var data = $.parseJSON(response);

                        if (data.status == 1) {

                            location.reload();
                        } else {

                            alert(data.message);
                        }
                    })
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dsprituz/epro.dspro.website/resources/views/admin/list_client.blade.php ENDPATH**/ ?>