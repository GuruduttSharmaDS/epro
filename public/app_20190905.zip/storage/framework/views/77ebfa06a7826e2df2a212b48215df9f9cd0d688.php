<div class="total_search">
								<!--<div class="total_count">01-48 of 57143 results for "<b>Private Security</b>"
								</div>-->
								<?php 
									if(isset($_POST) && !empty($_POST)){
								?>
								<div class="total_filter">
									<ul>
										<?php
										if(isset($_POST['category']) && !empty($_POST['category'])){
											foreach($_POST['category'] as $category){
												$category = user_category_data($category);
												echo "<li>".$category->category_name."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['price']) && !empty($_POST['price'])){
											foreach($_POST['price'] as $price){
												echo "<li>".$price."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['gender']) && !empty($_POST['gender'])){
											foreach($_POST['gender'] as $gender){
												echo "<li>".$gender."</li>";
											}
										}
										?>
										<?php
										if(  isset($_POST['duration']) && !empty($_POST['duration'])){
											foreach($_POST['duration'] as $duration){
												echo "<li>".$duration."</li>";
											}
										}
										?>
										<?php
										if( isset($_POST['weapon']) &&  !empty($_POST['weapon'])){
											foreach($_POST['weapon'] as $weapon){
												echo "<li>".$weapon."</li>";
											}
										}
										?>
																			
									</ul>
									<a href="<?php echo e(route('search-result')); ?>"><i class="fas fa-times-circle"></i> Clear all Filters</a>
								</div>

								<?php

									}
								?>
								
							</div>
							
							 <?php
							if(!empty($users)){

                                           if(!empty($user->image)){
                                             $img = $user->image;
                                         }else{
                                        $img = 'no-img.png';

                                         }
                                           
                                            
                            ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
							<div class="freelancer_list">

								<div class="profile">
									<div class="img_fP">
										<img src="<?php echo e(asset('/uploads/'.$img)); ?>" alt="">
									</div>
									<div class="name_loct">

										<h3><a class="checkuserLogin" href="<?php echo e(asset('/gaurd-detail/'.$user->id)); ?>"
											>
											<?php echo e($user->first_name.' '.$user->last_name); ?>

										</a> 
										<?php if($user->is_user_verified == '1'): ?>
										<span class="verified"><i class="fas fa-check"></i> Verified</span></h3>
										<?php endif; ?> 
											
										<h4><?php if(!empty($user->category_detail)): ?><?php echo e($user->category_detail->category_name); ?><?php endif; ?></h4>
										<div class="location">
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/loct.png'); ?>" alt="Location"> Location</span>
													<b><?php echo e($user->country); ?></b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/rate_img.png'); ?>" alt="Rate"> Rate</span>
													<b>$<?php echo e($user->price); ?>/hr</b>
												</h4>
												<h4>
													<span><img src="<?php echo asset('assets/frontend/img/success.png'); ?>" alt="Success">Success</span>
													<b>95%</b>
												</h4>
										</div>
									</div>
									<div class="star_rate">
											<div class="rating">
												<h3>5.0</h3>
											<ul>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
												<li><i class="fas fa-star"></i></li>
											</ul>
											</div>											
											<h4>(860 Feedbacks)</h4>
										</div>
								</div>
								<div class="details">
									<p><?php echo e($user->about); ?></p>
									<?php

								    $skills = user_skill_data($user->id);
								    if(!empty($skills)){
								    	?>
								    	<div class="soft_skills">
										<ul>
									    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <li><?php echo e($skill->skill_data->skill); ?></li>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									    </ul>
										</div>	
								    <?php	
									}
									 ?>
								</div>
							</div>
							 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							 <div class="paginating">

									<ul class="pagination searchpagination">
									<?php echo e($users->links()); ?>	
								
								</ul>
								</div>

							<?php 
							}else{

								echo "no record found";

							}
							?>

							
							<?php /**PATH C:\wamp64\www\epro\resources\views/ajax_gaurd_view.blade.php ENDPATH**/ ?>