<!DOCTYPE html>
<html lang="en">
<head>
    <title>freelancEP</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Add the slick-theme.css if you want default styling -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>
    <!-- Add the slick-theme.css if you want default styling -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"/>
    <link rel="icon" href="<?php echo asset('assets/frontend/img/favicon.png'); ?>" type="img/png" sizes="16x16">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="stylesheet" href="<?php echo asset('assets/frontend/css/style.css'); ?>">
</head>
<body>
    <div class="wrapper">
        <header>
            <nav class="navbar navbar-expand-md navbar-light">
                <div class="toggle_logo">
                    <a class="navbar-brand" href="#"><img src="<?php echo asset('assets/frontend/img/logo.'); ?>png"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <div class="call_service">
                    <h3><span>
                        <!-- <img src="<?php echo asset('assets/frontend/img/call.'); ?>png" alt="call service"> --> <i class="far fa-clock"></i></span>On-Call Service 24/7</h3>
                        <h2><b>(844) 707-0574</b><br>
                        24/7 Hour Business Line</h2>
                    </div>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.html">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">About us</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Events Security</a>
                            </li>    
                            <li class="nav-item">
                                <a class="nav-link" href="#">Security Services</a>
                            </li>    
                            <li class="nav-item">
                                <a class="nav-link" href="#">Faq</a>
                            </li>    
                            <li class="nav-item">
                                <a class="nav-link" href="#">Contact Us</a>
                            </li>    
                        </ul> 
                    </div>
                    <div class="login_regis">
                        <div class="login_action">
                            <a href="javascript:" data-toggle="modal" data-target="#login_regis">Log in / Register</a>
                        </div>
                        <form class="form-inline search_form">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                            <a class="submit_btn"><img src="<?php echo asset('assets/frontend/img/searc'); ?>h.png" width="18px"></a>
                        </form>
                    </div>
                </nav>
            </header>
   


         <?php echo $__env->yieldContent('body'); ?>




                   <footer>
                    <div class="logo_social">
                        <div class="container">
                            <div class="row">      
                                <div class="col-md-9 col-6">
                                    <div class="footer_logo">
                                        <img src="<?php echo asset('assets/frontend/img/foote'); ?>r_logo.png" alt="footer" class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-3 col-6">
                                    <div class="social">
                                        <ul>                            
                                            <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="" ><i class="fab fa-twitter"></i></a></li>
                                            <li><a href=""><i class="fab fa-linkedin-in"></i></a></li>
                                            <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="links_footer">
                        <div class="container">
                            <div class="row">      
                                <div class="col-md-4">
                                    <div class="our_links">
                                        <h3>About Us</h3>
                                        <p>The Love Boat promises something for every the beat of very best to a make the others comfortable.</p>
                                        <ul>               
                                            <li><i class="far fa-envelope"></i>+880 256794, 24-2564687</li> 
                                            <li><i class="fas fa-phone fa-rotate-90"></i>info@freelanceep.com</li>              
                                        </ul>           
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="sitemap_links">
                                        <div class="sitemap">
                                            <h3>Service Links</h3>
                                            <ul>
                                                <li><a href="#">Office Security</a></li>
                                                <li><a href="#">cctv Security</a></li>
                                                <li><a href="#">house Security</a></li>
                                                <li><a href="#">bank Security</a></li>
                                                <li><a href="#">Parking Security</a></li>
                                                <li><a href="#">Man Security</a></li>
                                            </ul>
                                        </div>
                                        <div class="sitemap useful_links">
                                            <h3>Support Links</h3>
                                            <ul>
                                                <li><a href="#">Support Link</a></li>
                                                <li><a href="#">Faq & Help Center</a></li>
                                                <li><a href="#">About Us</a></li>
                                                <li><a href="#">Create Account</a></li>
                                                <li><a href="#">Service and Help</a></li>
                                                <li><a href="#">Contact Us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>       
                                <div class="col-md-4">
                                    <div class="news_letters">
                                        <h3>Sign Up For a Newsletter</h3>
                                        <form action="">
                                            <h4>Weekly breaking news, analysis and cutting edge advices on job searching.</h4>
                                            <input type="text" placeholder="Enter your email address" required=""><button><i class="fas fa-arrow-right"></i></button>
                                        </form>
                                    </div>
                                </div>              
                            </div>
                        </div>
                    </div>
                    <div class="copyright">
                        <div class="col-12">                    
                            <p class="copy_right">© 2019 FreelanceEP. All Rights Reserved.</p>                      
                        </div>
                    </div>
                </footer>
            </div>
        </body>
                <script>
            $(document).ready(function(){
                $(".slider").slick({
                    slidesToShow: 3,
                    infinite: true,
                    autoplay: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
// search box
$('.search_form .submit_btn').click(function(){
    $('.form-inline input').toggleClass('showInput');
});


// Disable form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Get the forms we want to add validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
});
</script>

<!-- The Register Modal -->
<div class="modal" id="login_regis">
    <div class="modal-dialog  modal-dialog-centered ">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h1 class="modal-title">Register</h1>
                <button type="button" class="close" data-dismiss="modal"  title="close popup"><img src="<?php echo asset('assets/frontend/img/X.png'); ?>" alt="close form"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="via_social">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-square"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-google-plus-square"></i>Google Plus</a></li>
                    </ul>
                </div>
                <div class="or">
                    <span>Or</span>
                </div>
            </div>
            <div class="login_form">
                <form action="/action_page.php" class="needs-validation" novalidate>
                    <div class="form-group">
                        <label for="uname">Username:</label>
                        <input type="text" class="form-control" id="uname"  name="uname" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group">
                        <label for="uname">Email:</label>
                        <input type="text" class="form-control" id="email"  name="email" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="pwd"  name="pswd" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Confirm Password:</label>
                        <input type="password" class="form-control" id="cpwd" name="cpswd" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group">
                        <input class="form-check" type="checkbox" name="remember" required id="agree">
                        <label class="form-check-label" for="agree">                            
                            I agree with our <a href="#">Terms & Conditions</a>
                            <div class="valid-feedback">Valid.</div>
                            <div class="invalid-feedback">Check this checkbox to continue.</div>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-regis">Register</button>
                    <h3>Already Registered? <a href="javascript:" data-toggle="modal" data-target="#login_signin" data-dismiss="modal">Login Now</a></h3>
                </form>
            </div> 
        </div>
    </div>
</div>

<!-- The Login Modal -->
<div class="modal" id="login_signin">
    <div class="modal-dialog  modal-dialog-centered ">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h1 class="modal-title">Login</h1>
                <button type="button" class="close" data-dismiss="modal" title="close popup"><img src="<?php echo asset('assets/frontend/img/X.png'); ?>" alt="close form"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <div class="via_social">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-square"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-google-plus-square"></i>Google Plus</a></li>
                    </ul>
                </div>
                <div class="or">
                    <span>Or</span>
                </div>
            </div>
            <div class="login_form">
                <form action="/action_page.php" class="needs-validation" novalidate>
                    <div class="form-group">
                        <label for="uname">Username:</label>
                        <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <div class="forgot">
                        <a href="">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn btn-primary btn-regis">Login</button>
                    <h3>Don't have a login? <a href="javascript:" data-toggle="modal" data-target="#login_regis" data-dismiss="modal">Register now</a></h3>
                </form>
            </div>  
        </div>
    </div>
</div>
</html>        <?php /**PATH C:\xampp\htdocs\freelancep\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>