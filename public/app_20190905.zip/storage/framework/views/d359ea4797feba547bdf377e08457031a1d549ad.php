<?php $__env->startSection('title', 'FreelanceEP'); ?>
<?php $__env->startSection('body'); ?>

<div class="banner_search">
				<h1><?php echo $pageTitle; ?></h1>				
			</div>	
			<div class="search_main">
				<div class="container">
					<div class="row">
						 <?php echo $__env->make("frontend.layouts.user_dashboard_sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="col-12 col-md-8 col-lg-8 col-sm-7">
							<div class="hire_companies">
								<label>Name : <?php echo e($user->first_name.' '.$user->last_name); ?></label>
								<label>Email : <?php echo e($user->email); ?></label>
								<label>Category : <?php if(!empty($user->category_detail)): ?><?php echo e($user->category_detail->category_name); ?><?php endif; ?></label>
								<label>Price : $<?php echo e($user->price); ?>/hr</label>
								<label>Pincode : $<?php echo e($user->pincode); ?>/hr</label>
								<label>Price : $<?php echo e($user->price); ?>/hr</label>
								<label>About me : $<?php echo e($user->about); ?>/hr</label>

							</div>
						</div>
					</div>
				</div>
			</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.user_dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\epro\resources\views/user_profile.blade.php ENDPATH**/ ?>