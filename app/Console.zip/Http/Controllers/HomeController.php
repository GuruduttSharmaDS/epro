<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
// use App\Helpers\Common_helper::class;
use Session;
use DB;


class HomeController extends Controller
{
  public function index(){

   // $users = DB::select('select user.id, user.*, (SELECT skill from fp_skills where fp_skills.id  = (SELECT skill_id from fp_user_skills where fp_user_skills.user_id  = user.id limit 0,1)  limit 0,1) as skill from fp_users as user where user.status =0');
       $users = User::with(['category_detail'])
       ->where('status', '=', '0')
       ->get();
        return view("welcome",['users'=>$users]);
  }
  public function searchResult(){
    // $vvv = Common_helper::skills();
    // echo $price = formatNumber(11111.55555, 'IDR'); exit;
    // print_r($vvv);
      /*$users = DB::table('fp_users as U') 
      ->leftjoin('fp_user_skills as us', function($join) {
        $join->on('U.id', '=', 'us.user_id');
        })
      ->leftjoin('fp_skills as s', function($join) {
        $join->on('s.id', '=', 'us.skill_id');
        })
      ->groupBy('us.user_id')
       ->where('U.status', '=', '0')
       ->get();
*/
    $users = User::with(['category_detail'])
       ->where('status', '=', '0')
       ->get(); 
  	return view("searchresult",['users'=>$users]);
  }
  public function logout(Request $request){
  	
  	$request->session()->flush();
    Session::forget(['email','roleId','role','first_name','last_name']); 
    return redirect("/");
  }
  public function dashboard(){
  	return view("dashboard");
  }
  public function forgotpassword(Request $request){
  	/*return $request;
  	exit();*/
  	return view("newpassword");
  }
}