<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Validator;
use DB;
use App\Helpers\Common_helper;
use Session;
use Input;

use Mail;

class CommonController extends Controller
{
  public function index(Request $request){
    
        $action='';
    if (! $request->action) {
      /*print_r($_POST);
    exit();*/
    }
    $action=$request->action;
    $data=$request;
    if($action=="registration_Form")
      $return['valid'] =  $this->registration_Form($data);
    else if($action=="login_Form")
      $return['valid'] = $this->login_Form($data);
    else if($action=="forgot_Form")
      $return['valid'] = $this->forgot_Form($data);
    else if($action=="password_mail")
      $return['valid'] = $this->password_mail($data);

    return response()->json(['success'=>$return]);
    /*$this->output->set_content_type('application/json')->set_output(json_encode($return));*/
  
  }
  public function registration_Form($data){
       $response = array('valid' => false, 'data'=>'Invalid Request');  
       $id = 0;
       DB::beginTransaction();
       if($data->has('password')){
        try{

        $isExist = DB::select("SELECT * FROM fp_auths WHERE role = 'user' and (email = '".$data->email."' )",[1]);
       if(empty($isExist)){
       $common_lib = new Common_helper();
       $slug = $common_lib->createSlug($data->firstname,$id,'fp_users');
        
       $userdata = array('first_name' => $data->firstname, 'last_name'=>$data->lastname, 'email' => $data->email, 'slug' => $slug);
      $id = DB::table('fp_users')->insertGetId($userdata);

      $userauthdata = array('role'=>'user','role_id'=>$id,'email'=>$data->email,'password'=>bcrypt($data->password),'created_at'=>date('Y-m-d H:i:s'));
       $success= DB::table('fp_auths')->insert($userauthdata);
       DB::commit();
       Session::put(['email'=>$data->email,'roleId'=>$id,'role'=>'user','first_name'=>$data->firstname,'last_name'=>$data->lastname]);
       
      $response = array('valid' => true, 'data' => 'Successfully register') ;
      }
      
      else{
      $response['data'] = 'This email is already in use, Please try with another email Id';
      }
  } 
  catch (\Exception $e) {
    DB::rollback();
    // something went wrong
  }
      } 
      return $response;

  }
  public function login_Form($data)
  {
    $response = array('valid' => false, 'data'=>'Invalid Request');
    /*print_r($data->password);
    exit();*/
    if($data->has('username')){
    /*$logindata = DB::table('fp_auths')->where('email', '=', $data->email)->get();*/
    $email    = $data->username;
    $pass       = $data->password; 
    $hashed = Hash::make($pass);

    $isExist = DB::select("SELECT au.*, us.id, us.first_name, us.last_name, us.email, us.status  FROM fp_auths as au left join fp_users as us on (us.id = au.role_id AND au.role ='user') WHERE au.email = '".$data->username."' ",[1]);
    /*$response['data'] = "SELECT au.*, us.id, us.first_name, us.last_name, us.email, us.status  FROM fp_auths as au left join fp_users as us on (us.id = au.role_id AND au.role ='user') WHERE au.email = '".$data->username."' ";*/
    /*print_r ($isExist[0]->role_id);
    exit();*/

    if($isExist[0]){
        if($isExist[0]->status == 0){ 
          if(Hash::check($data->password,$isExist[0]->password)){
          Session::put(['email'=>$isExist[0]->email,'roleId'=>$isExist[0]->id,'role'=>'user','first_name'=>$isExist[0]->first_name,'last_name'=>$isExist[0]->last_name]);
         $response = array('valid' => true, 'data'=>'Logged in successfully.',  'role'=>$isExist[0]->role, 'firstname'=>$isExist[0]->first_name, 'lastname'=>$isExist[0]->last_name, 'mobile'=>$data->mobile);
          }
          else{
           $response['data'] = 'Password is not correct';   
          }
        }
        else{
            Session::forget(['email'=>$isExist[0]->email,'roleId'=>$isExist[0]->id,'role'=>'user','first_name'=>$isExist[0]->first_name,'last_name'=>$isExist[0]->last_name]);
         $response['data'] = 'Sorry! Your profile is inactive, Please Contact to admin';
        }
    }
    else
                $response['data'] = 'Soory! Invalid credentials, Try again.';
    }
    return $response;
  }
  public function forgot_Form($data)
  {
    $response = array('valid' => false, 'data'=>'Invalid Request');
    if($data->has('email')){
       $isExist = DB::select("SELECT * FROM fp_auths WHERE email = '".$data->email."'",[1]);
       if (!empty($isExist[0])) {
              if ($isExist[0]->email == $data->email) {
                $common_lib = new Common_helper();
                $token = $common_lib->generateStrongPassword(20,false,'lud');
                $code = date('Ymdhis').$token;
                /*$isUpdated = DB::table('fp_validcoupon')->where(['status'=>0,'email'=>$data->email])->update(['validtoken' => $code]);*/
                $match = array('email' => $isExist[0]->email, 'status' => 0);
                $isInsert = DB ::table('fp_validcoupon')->updateOrInsert($match,['validtoken' => $code,'status'=>0]);
                //return $isExist[0]->email;
                if ($isInsert) {
                  if(!empty($isExist[0]->email)){
                      $emailId = '';
                      $user = $isExist[0]; 
                       Mail::send('email_templates.forgot_password', ['url'=>asset('/set-new-password').'/'.$code], function ($m) use ($user) {
                          $m->to($user->email, 'User')->subject('Password reset!');
                      });
                  }
                  $response = array('valid' => true, 'data'=>'Password reset link has been sent to your email');
                }
                else
                  $response['data'] = 'Something is wrong';  
              }
              else
                $response['data'] = 'Sorry! Your profile is inactive, Please Contact to admin';
       }         
    }  
    return $response;
  }
  
  public function password_mail($data)
  { 
    
    $response = array('valid' => false, 'data'=>'Invalid Request');
    if($data->has('email') && $data>has('password') ){
      
    }
    else{
      $response['data'] = 'Something is wrong';
    }
    return $response; 
  }


}